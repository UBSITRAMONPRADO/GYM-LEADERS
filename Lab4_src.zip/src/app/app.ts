import { Component } from '@angular/core';
import { KantoRegionComponent } from './gym-kanto/gym-kanto';
import { JohtoRegionComponent } from './gym-johto/gym-johto';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [KantoRegionComponent, JohtoRegionComponent],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent {
  title = 'GymLeaders';
}
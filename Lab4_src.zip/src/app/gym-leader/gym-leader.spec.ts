import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GymLeaderComponent } from './gym-leader';


describe('GymLeaderComponent', () => {
  let component: GymLeaderComponent;
  let fixture: ComponentFixture<GymLeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GymLeaderComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(GymLeaderComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
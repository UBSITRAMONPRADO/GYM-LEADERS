import { Injectable,signal} from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class TrainerService {
  private registry = signal([
    { 
      name: 'Ash Ketchum', 
      team: ['Pikachu', 'Charizard'], 
      items: ['Light Ball', 'Charizardite Y'] 
    },
    { 
      name: 'Misty', 
      team: ['Starmie', 'Psyduck', 'Gyarados'], 
      items: ['Mystic Water', 'None', 'Gyaradosite'] 
    },
  ]);

  //Expose the signal as read-only
  trainers = this.registry.asReadonly();
}
